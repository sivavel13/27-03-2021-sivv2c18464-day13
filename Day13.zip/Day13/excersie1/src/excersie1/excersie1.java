package excersie1;

import java.util.ArrayList;
import java.util.*;

class lectures
{
	int LectureId;
	int IDclsA;
	int IDclsB;
	String lecturesA;
	String ProfessorA;
	String lecturesB;
	String ProfessorB;	
	
	public lectures(int LectureId, int IDclsA, String lecturesA, String ProfessorA, int IDclsB, String lecturesB, String ProfessorB) 
	{
		super();
		this.LectureId = LectureId;
		this.IDclsA = IDclsA;
		this.IDclsB = IDclsB;
		this.lecturesA = lecturesA;
		this.ProfessorA = ProfessorA;
		this.lecturesB = lecturesB;
		this.ProfessorB = ProfessorB;
	}
}

public class excersie1 {
	
	
	public static void main(String[] args) {
		ArrayList <lectures> lect = new ArrayList <lectures>();
		
		lectures lect1 = new lectures (1,1,"Tamil","Tom",1,"Tamil","Tommy"); 
		lectures lect2 = new lectures (2,2,"Mathas","Tony",2,"Science","Stark");  
		lectures lect3 = new lectures (3,3,"Science","Stark",3,"Physics","Jack"); 
		lectures lect4 = new lectures (4,4,"Physics","Jack",4,"Tamil","Tom");
		
		lect.add(lect1);
		lect.add(lect2);
		lect.add(lect3);
		lect.add(lect4);
		
		for (lectures l : lect) {
			if (l.lecturesA == l.lecturesB) {
				if (l.ProfessorA == l.ProfessorB) {
					System.out.println("Please rearrange the  "  +  l.LectureId  + " period have same subject and same Professors");
				}
				else {
					System.out.println(l.LectureId + " Period no issues same subjects have same time but different Professors");
					System.out.println(l.LectureId + " Period subjects Class- A:" + l.lecturesA + " Professor name: " + l.ProfessorA + "  "+"Class- B: " + l.lecturesB +"  " + " Professor name: " + l.ProfessorB);
				}
			
			}
			else {
				System.out.println(l.LectureId +" period perfect");
				System.out.println(l.LectureId + " Period subjects Class- A:" + l.lecturesA + " Professor name: " + l.ProfessorA + "  "+"Class- B: " + l.lecturesB +"  " + " Professor name: " + l.ProfessorB	);
				
				
			
			}			
		}
			
	}

}

 
